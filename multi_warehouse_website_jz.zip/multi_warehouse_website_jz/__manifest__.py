# -*- coding: utf-8 -*-
{
    "name": "Multi Almacen Website",
    "summary": "Multi Almacen Website",
    "description": """
        Stock Multi Almacen Website
    """,
    "author": "Jzolutions",
    "category": "Uncategorized",
    "version": "17.0",
    "depends": ["website_sale","website_sale_stock"],
    "data": [
        "security/ir.model.access.csv",
        'views/templates.xml',
        #'views/view_warehouse.xml'
    ],
    "application": False,
    "installable": True,
    "auto_install": False,
    'assets': {
        #'web.assets_frontend': [
        #    'stock_multi_location_website_jz/static/src/js/website_sale.js',
        #],


     },

}
