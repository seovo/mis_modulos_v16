
import math
from odoo import api, fields, models
from odoo.exceptions import UserError

class SaleOrder(models.Model):
    _inherit       = 'sale.order'
    state_encomienda = fields.Selection([
        ('1','Transito Caja Rural al Cenam'),
        ('2','Despacho a USA'),
        ('3', 'Salio a Aduana'),
        ('4', 'Entregado'),
    ],default='1',string="Estado Encomienda")

    clase_encomienda  = fields.Selection([
        ('doc','Documento'),
        ('mer','Mercaderia'),
    ],string="Clase de Encomienda")

    type_doc_encomienda  = fields.Selection([
        ('doc','Legales'),
        ('pass','Pasaporte'),
        ('lic','Licencia'),
        ('other','Otro')
    ],string="Clase de Documentos")
    packing_list_ids = fields.One2many('sale.order.packing.list','order_id')
    total_peso_cobro = fields.Float(compute='get_total_peso_cobro', string='Peso Cobro')

    def _compute_has_active_pricelist(self):
        res = super()._compute_has_active_pricelist()

        for order in self:
            order.has_active_pricelist = False
        return res

    def get_total_peso_cobro(self):
        for record in self:
            total_peso_cobro = 0
            for line in record.order_line:
                total_peso_cobro += line.total_peso_cobro
            record.total_peso_cobro = total_peso_cobro


    def action_confirm(self):
        res = super().action_confirm()
        if self.carrier_id:
            for line in self.order_line:
                carrier = self.carrier_id
                if line.product_id == self.carrier_id.product_id:
                    line.unlink()
                self.carrier_id = carrier.id

        return res

    #PACKING LIST

class SaleOrderPackingList(models.Model):
    _name = "sale.order.packing.list"
    _description = "sale.order.packing.list"

    order_id = fields.Many2one('sale.order')
    display_type = fields.Selection(
        selection=[
            ('line_section', "Section"),
            ('line_note', "Note"),
        ],
        default=False)
    sequence = fields.Integer(string="Sequence", default=10)
    qty = fields.Float(string="Cantidad",default=1)
    type_mercaderia = fields.Selection([
        ('food_refrigeration','Comida que requiere refrigeración'),
        ('sweet', 'Dulces típicos'),
        ('broth', 'Caldo'),
        ('food_registration', 'Comida con registros ejemplo tortrix o boquitas Diana'),
        ('beer','Cerveza'),
        ('medicines', 'Medicinas'),
        ('creams', 'Cremas'),
        ('clothes', 'Ropa'),
        ('other', 'Otros Especificar :'),
    ],required=True,string="Mercaderia")
    name = fields.Text(string="Descripción")
    code_hds = fields.Char(string="Codigo HDS")

class SaleOrderLine(models.Model):
    _inherit        = 'sale.order.line'
    encomienda_list = fields.One2many('sale.order.line.encomienda.list','sale_order_line_id')
    is_encomienda   = fields.Boolean(related='product_id.is_encomienda')
    price_fixed     = fields.Float(string='Valor Primera Lbs')
    price_total_encomienda =  fields.Float(compute='change_items_encomienda',string='Cargos Extras')
    cost_price_cobro = fields.Float(compute='change_items_encomienda',
                                    string='Valor Flete' ,
                                    help='(Precio Cobro - 1 ) * Precio Extra Libra')
    price_extra_libre = fields.Float(string='Precio Extra Libra')
    total_peso_cobro = fields.Float(compute='change_items_encomienda',string='Peso Cobro')

    @api.onchange('product_id')
    def change_price_fixed(self):
        for line in self:
            line.price_fixed = line.product_id.list_price
            line.price_extra_libre  = line.product_id.price_extra_libre

    @api.onchange('encomienda_list','encomienda_list.amount_total')
    def change_items_encomienda(self):
        for record in self:
            if record.product_id:

                total_peso_cobro = 0
                cost_peso_cobro = 0
                total_price = 0

                for line in record.encomienda_list:
                    total_peso_cobro  += line.weight_cobrar
                    total_price +=  line.amount_total

                if total_peso_cobro > 0 :
                    cost_peso_cobro = total_peso_cobro - 1
                    cost_peso_cobro = cost_peso_cobro * record.price_extra_libre

                record.total_peso_cobro = total_peso_cobro
                record.cost_price_cobro = cost_peso_cobro
                record.price_total_encomienda = total_price

                record.price_unit = record.price_fixed + cost_peso_cobro + total_price

    def edit_price_jz(self):

        if not self.is_encomienda:
            return

        if self.price_fixed == 0  or not self.price_fixed:
            self.change_price_fixed()

        view = self.env.ref('encomiendas_guatemala.edit_sale_order_line')
        return {
            "name": f"EDIT PRICE :   {self.name}",
            "type": "ir.actions.act_window",
            "view_mode": "form",
            "res_model": "sale.order.line",
            "target": "new",
            "res_id": self.id ,
            "view_id": view.id
        }

    def _action_launch_stock_rule(self, previous_product_uom_qty=False):
        for line in self:
            if  line.product_id.is_encomienda:
                return

        res = super()._action_launch_stock_rule(previous_product_uom_qty=previous_product_uom_qty)
        return res


class SaleOrderEncomiendaList(models.Model):
    _name = "sale.order.line.encomienda.list"
    _description = "sale.order.encomienda.list"

    sale_order_line_id = fields.Many2one('sale.order.line')
    qty = fields.Float(string="Cantidad",default=1)
    product_id = fields.Many2one('product.product',string="Producto",required=True)
    price_unit = fields.Float(string="Precio")
    precio_cost = fields.Float(string="Costo")
    peso_real   = fields.Float(string="Peso Real (lb)")
    largo       = fields.Float(string="Largo (cm)")
    ancho       = fields.Float(string="Ancho (cm)")
    alto        = fields.Float(string="Alto (cm)")
    weight_vol  = fields.Float(string="Peso Volumen",compute='get_weight_vol')
    weight_cobrar = fields.Float(string="Peso Cobro",compute='get_weight_vol')
    amount_total = fields.Float(string="Total",compute="get_amount_total")

    @api.depends('price_unit','qty')
    def get_amount_total(self):
        for record in self:
            record.amount_total = record.price_unit * record.qty


    @api.depends('peso_real','largo','ancho','alto')
    def get_weight_vol(self):
        for record in self:

            mult =  ( record.largo * record.ancho * record.alto ) / 5000

            weight_vol =  mult * 2.2046

            record.weight_vol =  math.ceil(weight_vol)

            max_vol = max(weight_vol,record.peso_real)

            record.weight_cobrar = math.ceil(max_vol)

    @api.onchange('product_id')
    def change_product(self):
        for record in self:
            record.price_unit = record.product_id.list_price
            record.precio_cost = record.product_id.standard_price

            #raise ValueError('okkk')

            record.peso_real = record.product_id.weight
            record.largo = record.product_id.largo_enc
            record.ancho = record.product_id.ancho_enc
            record.alto = record.product_id.alto_enc








