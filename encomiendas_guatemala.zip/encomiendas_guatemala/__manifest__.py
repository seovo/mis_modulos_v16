# -*- coding: utf-8 -*-
{
    "name": "Encomiendas Guatemala",
    "summary": "Encomiendas Guatemala",
    "description": """Encomiendas Guatemala""",
    "author": "Jzolutions",
    "category": "Uncategorized",
    "version": "17.0",
    "depends": ["website_sale"],
    "data": [
        "security/ir.model.access.csv",
        'views/templates.xml',
        'views/sale_order.xml',
        'views/res_partner.xml',
        'views/product.xml',
        'views/report_templates.xml'
    ],
    # 'uninstall_hook': 'uninstall_hook',
    #"external_dependencies": {"python": ["msal","pymssql","pandas"]},
    "application": False,
    "installable": True,
    "auto_install": False,

}
